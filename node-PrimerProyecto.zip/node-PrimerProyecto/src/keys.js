module.exports ={
    database:{
        host:'localhost',
        user:'root',
        password:'4743488',
        database:'database_links',
    }
};